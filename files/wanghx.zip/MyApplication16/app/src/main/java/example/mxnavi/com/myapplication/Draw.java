package example.mxnavi.com.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

/**
 * Created by Administrator on 2018/7/16.
 */





public class Draw extends View {
    public Draw(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(MxColor.WHITE);
        Paint mPaint = new Paint();
        mPaint.setAntiAlias(true);

        mPaint.setTextSize(100f);
        int width = getWidth();
        int heiht = getHeight();
        float x = width * 0.5f;
        float y = heiht * 0.4f;
        Path path = new Path();

        mPaint.setColor(MxColor.LIGHT_YELLOW);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y*3/4);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();
        mPaint.setColor(MxColor.YELLOW);
        path.moveTo(x,y);
        path.lineTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.close();
        canvas.drawPath(path,mPaint);

        canvas.rotate(90,x,y);
        path.reset();
        mPaint.setColor(MxColor.LIGHT_RED);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y*3/4);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();
        mPaint.setColor(MxColor.RED);
        path.moveTo(x,y);
        path.lineTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.close();
        canvas.drawPath(path,mPaint);

        canvas.rotate(90,x,y);
        path.reset();
        mPaint.setColor(MxColor.LIGHT_BLUE);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y*3/4);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();
        mPaint.setColor(MxColor.BLUE);
        path.moveTo(x,y);
        path.lineTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();

        canvas.rotate(90,x,y);
        path.reset();
        mPaint.setColor(MxColor.LIGHT_GREEN);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y*3/4);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();
        mPaint.setColor(MxColor.GREEN);
        path.moveTo(x,y);
        path.lineTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.close();
        canvas.drawPath(path,mPaint);
        path.reset();

        mPaint.setColor(MxColor.WHITE);
        canvas.drawCircle(x,y,30,mPaint);
        path.reset();

        Bitmap bitmap = ((BitmapDrawable)getContext().getResources().getDrawable(R.drawable.mxnavi))
                .getBitmap();
        canvas.rotate(90);

        canvas.scale(0.3f,0.3f,x,y);
        canvas.drawBitmap(bitmap,-350,-900,mPaint);


    }

}
