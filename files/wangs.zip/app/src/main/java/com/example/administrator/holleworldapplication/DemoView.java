package com.example.administrator.holleworldapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

/**
 * Created by Administrator on 2018/7/16.
 */

public class DemoView extends View {
    private int x;
    private int y;

    public DemoView(Context context) {
        super(context);
    }

    public DemoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        WindowManager windowManager = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(dm);
        x =  (dm.widthPixels)/2;
        y = (dm.heightPixels)*2/5;
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);
        //颜色数组
        int[] mint1 = {MxColor.LIGHT_YELLOW,MxColor.LIGHT_RED,MxColor.LIGHT_BLUE,MxColor.LIGHT_GREEN};
        int[] mint2 = {MxColor.YELLOW,MxColor.RED,MxColor.BLUE,MxColor.GREEN};

        for(int i=0;i<4;i++){
           Paint mPaint = new Paint();
           Path mPath = new Path();
            //判断等于1时不旋转
            if (i != 0){
                canvas.rotate(90,x,y);
            }
            mPaint.setColor(mint1[i]);
            mPaint.setAntiAlias(false);
            mPaint.setStyle(Paint.Style.FILL);
            mPath.moveTo(x,y);                        //点O
            mPath.lineTo(x-y/4,y/4*3);    //点A
            mPath.lineTo(x,y/2);                  //点B
            mPath.close();
            canvas.drawPath(mPath,mPaint);
            mPath.reset();
            mPaint.setColor(mint2[i]);
            mPath.moveTo(x,y/2);
            mPath.lineTo(x+y/2,y/2);
            mPath.lineTo(x,y);
            mPath.close();
            canvas.drawPath(mPath,mPaint);

        }

        //白圆
        Paint mPaintCircle = new Paint();
        mPaintCircle.setColor(MxColor.WHITE);
        canvas.drawCircle(x,y,20,mPaintCircle);

        //美行科技
        Paint mmPaint = new Paint();
        Bitmap bitmap = ((BitmapDrawable) getContext().getResources().getDrawable(R.drawable.mxnavi)).getBitmap();
        canvas.rotate(90,0,0);
        canvas.scale(0.2f,0.2f);
        canvas.drawBitmap(bitmap,x*1.5f,-y*2,mmPaint);

    }


}
