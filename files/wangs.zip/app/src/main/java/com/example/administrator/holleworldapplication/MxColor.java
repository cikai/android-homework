package com.example.administrator.holleworldapplication;

/**
 * Created by cikai on 2018/7/10.
 */

public class MxColor {

    public static int WHITE = 0xffffffff;

    public static int YELLOW = 0xfff39800;
    public static int LIGHT_YELLOW = 0xfffcd68c;

    public static int RED = 0xffe5005a;
    public static int LIGHT_RED = 0xfff5b2b2;

    public static int BLUE = 0xff014099;
    public static int LIGHT_BLUE = 0xff89a3d4;

    public static int GREEN = 0xff009944;
    public static int LIGHT_GREEN = 0xffa6d397;

}
