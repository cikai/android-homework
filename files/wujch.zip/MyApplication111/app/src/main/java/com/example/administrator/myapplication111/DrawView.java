package com.example.administrator.myapplication111;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;

/**
 * Created by Administrator on 2018/7/17.
 */
public class DrawView extends View{


    private int x;
    private int y;
    private Context context1;

    public DrawView(Context context) {
        super(context);
    }

    public DrawView(Context context,  int height, int width) {
        this(context);
        this.x = width/2;
        this.y = height*2/5;
        context1 = context;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawBitmap(canvas,context1);
        drawTriangle(canvas,0,MxColor.YELLOW,MxColor.LIGHT_YELLOW);
        drawTriangle(canvas,90,MxColor.RED,MxColor.LIGHT_RED);
        drawTriangle(canvas,180,MxColor.BLUE,MxColor.LIGHT_BLUE);
        drawTriangle(canvas,270,MxColor.GREEN,MxColor.LIGHT_GREEN);
        drawCircle(canvas);

    }


    void drawTriangle(Canvas canvas,float degrees,int color1,int color2){
        Paint paint1 = new Paint();
        paint1.setStyle(Paint.Style.FILL);
        paint1.setColor(color1);
        Path path1 = new Path();
        path1.moveTo(x,y);
        path1.lineTo(x-y/4,y/4*3);
        path1.lineTo(x,y/2);
        path1.close();
        canvas.rotate (degrees,x,y);
        canvas.drawPath(path1,paint1);

        Paint paint2 = new Paint();
        paint2.setStyle(Paint.Style.FILL);
        paint2.setColor(color2);
        Path path2 = new Path();
        path2.moveTo(x,y/2);
        path2.lineTo(x + y / 2,y / 2 );
        path2.lineTo(x,y);
        path2.close();
        canvas.drawPath(path2,paint2);
    }

    void drawCircle(Canvas canvas){
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(MxColor.WHITE);
        canvas.drawCircle(x,y,30,paint);
    }

    void drawBitmap(Canvas canvas,Context context1){
        Paint paint = new Paint();
        Bitmap bitmap = ((BitmapDrawable)context1.getResources().getDrawable(R.drawable.mxnavi)).getBitmap();
        canvas.drawBitmap(bitmap,0,y*5/2-250,paint);

    }


}