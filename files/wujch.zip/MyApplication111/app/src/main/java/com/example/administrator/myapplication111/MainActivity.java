package com.example.administrator.myapplication111;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;

public class MainActivity extends Activity {

    private int height;
    private int width;
    private String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DisplayMetrics z = getResources().getDisplayMetrics();
        height = z.heightPixels;
        width = z.widthPixels;


        DrawView v = new DrawView(getApplicationContext(), height, width);
        setContentView(v);
    }

}
