package com.mxnavi.canvardemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by zhaoll on 2018/7/16.
 */

public class TestView extends View {

    //private Context mContext;
    public TestView(Context context) {
        super(context);
    }

    public TestView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(com.mxnavi.canvardemo.Color.WHITE);

        int screenWidth = getWidth();
        int screenHeight = getHeight();

//        WindowManager wm = (WindowManager) this.getContext().getSystemService(Context.WINDOW_SERVICE);
//        DisplayMetrics dm = new DisplayMetrics();
//        wm.getDefaultDisplay().getMetrics(dm);
//        int width = dm.widthPixels;// 屏幕宽度（像素）
//        int height= dm.heightPixels; // 屏幕高度（像素）
//        float density = dm.density;//屏幕密度（0.75 / 1.0 / 1.5）
//        int densityDpi = dm.densityDpi;//屏幕密度dpi（120 / 160 / 240）
//        //屏幕宽度算法:屏幕宽度（像素）/屏幕密度
//        int screenWidth = (int) (width/density);//屏幕宽度(dp)
//        int screenHeight = (int)(height/density);//屏幕高度(dp)


        Paint paint = new Paint();
        Path path = new Path();
        paint.setColor(com.mxnavi.canvardemo.Color.LIGHT_YELLOW);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        // paint.setStrokeWidth(10f);
        // canvas.drawLine(200,200,300,400,paint);

        float x = screenWidth/2;
        float y = screenHeight/2.5f;
        path.moveTo(x,y);
        path.lineTo(x-y/4,y/4*3);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,paint);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.YELLOW);
        path.moveTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.lineTo(x,y);
        path.close();
        canvas.drawPath(path,paint);

        canvas.rotate(90,x,y);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.LIGHT_RED);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y/4*3);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,paint);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.RED);
        path.moveTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.lineTo(x,y);
        path.close();
        canvas.drawPath(path,paint);

        canvas.rotate(180,x,y);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.LIGHT_BLUE);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y/4*3);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,paint);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.BLUE);
        path.moveTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.lineTo(x,y);
        path.close();
        canvas.drawPath(path,paint);

        canvas.rotate(270,x,y);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.LIGHT_GREEN);
        path.moveTo(x,y);
        path.lineTo(x-y/4,y/4*3);
        path.lineTo(x,y/2);
        path.close();
        canvas.drawPath(path,paint);
        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.GREEN);
        path.moveTo(x,y/2);
        path.lineTo(x+y/2,y/2);
        path.lineTo(x,y);
        path.close();
        canvas.drawPath(path,paint);


        path.reset();
        paint.setColor(com.mxnavi.canvardemo.Color.WHITE);
        canvas.drawCircle(x,y,20,paint);


        canvas.rotate(180,x,y);
        canvas.scale(0.3f,0.3f);
        path.reset();
        Bitmap bitmap = ((BitmapDrawable)getContext().getResources().getDrawable(R.drawable.mxnavi)).getBitmap();
        canvas.drawBitmap(bitmap,x*1.25f,y*5.5f,paint);

    }

}
