package com.example.p.convasdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Demo demo = new Demo(getApplicationContext());
        setContentView(demo);
    }
}
